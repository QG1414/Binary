﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "C:\\Users\\uczen\\Desktop\\Dane_2305\\bin_przyklad.txt";
            string[] binaryLines = File.ReadAllLines(path);

            Console.Write("Podaj liczbę: ");
            int decimalNumber = int.Parse(Console.ReadLine());
            string binaryNumber = ConvertToBinary(decimalNumber);
            int numberOfBlocks = CalculateBinaryBlocks(binaryNumber);
            Console.WriteLine($"\nilość bloków: {numberOfBlocks}");


            int allCorrectBlocks = CalculateBinaryBlocksWithLimiter(binaryLines, 3);
            Console.WriteLine($"\nilość bloków w przykładzie: {allCorrectBlocks}");


            string largestBinary = FindLargestBinary(binaryLines);
            Console.WriteLine($"\nNajwieksza binarna liczba: {largestBinary}");


            Console.WriteLine();
            CalculateXorBinaries(binaryLines);

            Console.ReadKey();
        }

        static string ConvertToBinary(int decimalNumber)
        {
            string binaryVersion = "";
            int divisionRest;

            while(decimalNumber > 0)
            {
                divisionRest = decimalNumber % 2;
                decimalNumber = decimalNumber / 2;
                binaryVersion += divisionRest.ToString();
            }

            binaryVersion = SwapBinary(binaryVersion);

            return binaryVersion;
        }

        static string SwapBinary(string rawBinary)
        {
            string newString = "";
            for(int i = rawBinary.Length-1; i >=0; i--)
            {
                newString += rawBinary[i];
            }
            return newString;
        }

        static int CalculateBinaryBlocks(string binary)
        {
            int numberOfBlocks = 0;
            char lastDigit = '2';

            foreach(char oneCharacter in binary)
            {
                if(lastDigit != oneCharacter)
                {
                    numberOfBlocks++;
                    lastDigit = oneCharacter;
                }
            }

            return numberOfBlocks;
        }

        static int CalculateBinaryBlocksWithLimiter(string[] binary, int limiter)
        {
            int numberOfBlocks = 0;
            int temporaryNumber = 0;

            foreach(string binaryBlock in binary)
            {
                temporaryNumber = CalculateBinaryBlocks(binaryBlock);

                if(temporaryNumber < limiter)
                {
                    numberOfBlocks++;
                }
            }

            return numberOfBlocks;
        }

        static int ConvertBinaryToDecimal(string binary)
        {
            int finalNumber = 0;

            string swapedBinary = SwapBinary(binary);

            for(int i= 0; i< swapedBinary.Length; i++)
            {
                finalNumber += int.Parse(swapedBinary[i].ToString()) * CustomPow(2, i);
            }

            return finalNumber;
        }

        static int CustomPow(int a, int b)
        {
            if (b <= 0)
                return 1;

            int startingNumber = a;

            for(int i=1; i<b; i++)
            {
                a *= startingNumber;
            }

            return a;
        }

        static string FindLargestBinary(string[] binaryLines)
        {
            int largestNumber = 0;
            string largestBinary = "";
            int tempNumber = 0;
            foreach (string binary in binaryLines)
            {
                tempNumber = ConvertBinaryToDecimal(binary);

                if (tempNumber > largestNumber)
                {
                    largestNumber = tempNumber;
                    largestBinary = binary;
                }
            }

            return largestBinary;
        }

        static void CalculateXorBinaries(string[] binaryLines)
        {
            foreach (string binary in binaryLines)
            {
                int tempDecimal = ConvertBinaryToDecimal(binary);
                tempDecimal /= 2;
                string secondBinary = ConvertToBinary(tempDecimal);
                string newBinnary = XorBinary(binary, secondBinary);
                Console.WriteLine(newBinnary);
            }
        }

        static string XorBinary(string binary1, string binary2)
        {

            if(binary1.Length < binary2.Length)
            {
                for(int i=0; i<binary2.Length - binary1.Length; i++) {
                    binary1 = binary1.Insert(0, "0");
                }
            }
            else
            {
                for (int i = 0; i < binary1.Length - binary2.Length; i++)
                {
                    binary2 = binary2.Insert(0, "0");
                }
            }

            string newBinnary = "";

                for (int i = 0; i < binary1.Length; i++)
                {
                    if (binary1[i] == binary2[i])
                    {
                        newBinnary += "0";
                    }
                    else
                        newBinnary += "1";
                }
            


            return newBinnary;
            
        }


    }
}
